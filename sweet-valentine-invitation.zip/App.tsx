
import React, { useState } from 'react';
import ValentineCard from './components/ValentineCard';
import Celebration from './components/Celebration';

const App: React.FC = () => {
  const [isAccepted, setIsAccepted] = useState(false);
  const [aiMessage, setAiMessage] = useState<string>("");

  const handleAccept = () => {
    setIsAccepted(true);
    // Setting the specific cute message requested by the user
    setAiMessage("Love you forever, my baby shrimp, gugugaga! See u next week ❤️✨");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative Background Hearts */}
      <div className="absolute inset-0 pointer-events-none opacity-20 overflow-hidden">
         {[...Array(20)].map((_, i) => (
           <div 
             key={i} 
             className="absolute text-pink-300 animate-float"
             style={{
               left: `${Math.random() * 100}%`,
               top: `${Math.random() * 100}%`,
               fontSize: `${Math.random() * 40 + 20}px`,
               animationDelay: `${Math.random() * 5}s`,
               animationDuration: `${Math.random() * 3 + 3}s`
             }}
           >
             ❤️
           </div>
         ))}
      </div>

      {!isAccepted ? (
        <ValentineCard onAccept={handleAccept} />
      ) : (
        <Celebration message={aiMessage} />
      )}
      
      <footer className="fixed bottom-4 text-pink-400 text-sm italic opacity-60">
        Made with love for a special someone
      </footer>
    </div>
  );
};

export default App;
