
import { GoogleGenAI } from "@google/genai";

export async function generateSweetMessage(): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Write a very short, cute, and romantic 2-sentence response to someone who just said 'Yes' to being your Valentine. Use plenty of emojis.",
      config: {
        systemInstruction: "You are a charming, romantic, and adorable assistant. Your goal is to make the user feel special and loved.",
        temperature: 0.9,
      }
    });

    return response.text?.trim() || "You've made me the happiest person! I'm so excited for our first Valentine's together! ❤️✨";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I knew you'd say yes! You're the best thing that's ever happened to me. Can't wait for Feb 14th! 💕🌹";
  }
}
