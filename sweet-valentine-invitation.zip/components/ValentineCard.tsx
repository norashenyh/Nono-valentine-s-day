
import React, { useState } from 'react';

interface ValentineCardProps {
  onAccept: () => void;
}

const NO_MESSAGES = [
  "No",
  "Are you sure?",
  "Think again!",
  "Last chance!",
  "Surely not?",
  "You're breaking my heart! 💔",
  "Give it a thought!",
  "Pwease? 🥺",
  "Really? :( ",
  "You're being mean!",
  "I'm gonna cry...",
  "Click the other button!",
  "Just say YES already!"
];

const ValentineCard: React.FC<ValentineCardProps> = ({ onAccept }) => {
  const [noCount, setNoCount] = useState(0);
  const [noButtonPos, setNoButtonPos] = useState({ x: 0, y: 0 });
  
  const yesButtonSize = Math.min(1 + noCount * 0.3, 5);
  const noButtonSize = Math.max(1 - noCount * 0.1, 0.2);

  const handleNoClick = () => {
    setNoCount(prev => prev + 1);
    moveNoButton();
  };

  const moveNoButton = () => {
    const x = (Math.random() - 0.5) * 300;
    const y = (Math.random() - 0.5) * 300;
    setNoButtonPos({ x, y });
  };

  return (
    <div className="bg-white/80 backdrop-blur-md p-8 md:p-12 rounded-3xl shadow-2xl text-center max-w-md w-full border-4 border-pink-100 transform transition-all hover:scale-[1.02]">
      <div className="mb-8 relative h-40 flex items-center justify-center">
        {/* Animated Emoji Mascot - Using Teddy Bear instead of Cat */}
        <div className="text-8xl md:text-9xl animate-bounce filter drop-shadow-xl transition-all duration-500">
          {noCount > 5 ? '🧸💔' : noCount > 0 ? '🥺' : '🧸'}
        </div>
        <div className="absolute bottom-2 w-24 h-4 bg-pink-100/50 rounded-[100%] blur-md animate-pulse"></div>
      </div>
      
      <h1 className="text-4xl md:text-5xl font-cursive text-pink-600 mb-8 leading-tight">
        Will you be my Valentine?
      </h1>

      <div className="flex flex-wrap items-center justify-center gap-6 relative min-h-[120px]">
        <button
          onClick={onAccept}
          style={{ transform: `scale(${yesButtonSize})` }}
          className="bg-pink-500 hover:bg-pink-600 text-white font-bold py-3 px-8 rounded-full shadow-lg transition-all duration-200 z-10 active:scale-95"
        >
          Yes! ✨
        </button>

        <button
          onClick={handleNoClick}
          onMouseEnter={moveNoButton}
          style={{ 
            transform: `translate(${noButtonPos.x}px, ${noButtonPos.y}px) scale(${noButtonSize})`,
            opacity: noCount > 12 ? 0.2 : 1
          }}
          className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold py-3 px-8 rounded-full shadow-md transition-all duration-300 whitespace-nowrap"
        >
          {NO_MESSAGES[Math.min(noCount, NO_MESSAGES.length - 1)]}
        </button>
      </div>

      {noCount > 0 && (
        <p className="mt-8 text-pink-400 font-medium animate-pulse">
          {noCount > 8 ? "You can't say no forever! 😉" : "Think it over..."}
        </p>
      )}
    </div>
  );
};

export default ValentineCard;
