
import React, { useEffect, useState } from 'react';

interface CelebrationProps {
  message: string;
}

const Celebration: React.FC<CelebrationProps> = ({ message }) => {
  const [hearts, setHearts] = useState<number[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setHearts(prev => [...prev.slice(-50), Date.now()]);
    }, 200);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="text-center z-10 max-w-2xl px-4 flex flex-col items-center">
      {/* Falling Hearts */}
      {hearts.map(id => (
        <div
          key={id}
          className="heart-particle text-2xl"
          style={{
            left: `${Math.random() * 100}vw`,
            animationDuration: `${Math.random() * 2 + 3}s`,
            fontSize: `${Math.random() * 20 + 20}px`
          }}
        >
          {['❤️', '💖', '💝', '💕', '🌸'][Math.floor(Math.random() * 5)]}
        </div>
      ))}

      <div className="bg-white/95 backdrop-blur-lg p-10 rounded-[3rem] shadow-2xl border-4 border-pink-200 animate-bounce-short transform hover:scale-105 transition-transform duration-500">
        <div className="mb-6 relative h-56 flex items-center justify-center">
            {/* Stable Celebratory Mascot - Teddy Bear with Heart */}
            <div className="text-9xl animate-pulse filter drop-shadow-2xl">
              🧸❤️
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
               <div className="w-48 h-48 border-4 border-pink-300 border-dashed rounded-full animate-[spin_10s_linear_infinite] opacity-30"></div>
            </div>
            <div className="absolute -top-4 -right-4 text-4xl animate-bounce">✨</div>
            <div className="absolute -bottom-4 -left-4 text-4xl animate-bounce delay-75">✨</div>
        </div>
        
        <h2 className="text-5xl font-cursive text-pink-600 mb-6 drop-shadow-sm">Yaaaaay! 🎉</h2>
        
        <div className="space-y-4">
          <p className="text-2xl text-pink-500 leading-relaxed font-bold italic">
            "{message}"
          </p>
          <div className="flex justify-center gap-4 text-4xl animate-pulse">
            <span>🦐</span>
            <span>❤️</span>
            <span>🍼</span>
          </div>
        </div>
      </div>

      <button 
        onClick={() => window.location.reload()}
        className="mt-8 text-pink-400 hover:text-pink-600 underline font-medium transition-colors"
      >
        Click to see the cute card again
      </button>
    </div>
  );
};

export default Celebration;
